#ifndef MenuGen_h
#define MenuGen_h

// Tp3  manipulation MenuGen avec PEC12
// C. HUBER  03.02.2016
// Fichier MenuGen.h
// Gestion du menu  du g�n�rateur
// Traitement cyclique � 1 ms du Pec12


#include <stdbool.h>
#include <stdint.h>
#include "DefMenuGen.h"


void MENU_Initialize(S_ParamGen *pParam);


void MENU_Execute(S_ParamGen *pParam);
void MENU_Display(S_ParamGen *pParam, uint8_t menu);
#endif




  
   







